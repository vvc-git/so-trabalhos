# Trabalho de sistemas operacionais 2

Lembre-se que precisa dos arquivos cpu.cc para compilar
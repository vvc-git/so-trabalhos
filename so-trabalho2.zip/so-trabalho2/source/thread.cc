#include "thread.h"

__BEGIN_API
int Thread::_contador_threads=0;
Thread *Thread::_running = nullptr;


int Thread::switch_context(Thread * prev, Thread * next) {
    db<Thread>(INF) << "Thread::switch_context() chamado\n";
    prev->_running = next;
    next->_running = next;
    return CPU::switch_context(prev->_context, next->_context);

}

void Thread::thread_exit(int exit_code) {
    // Desaloca a memória associada ao contexto
    db<Thread>(INF) << "Thread::thread_exit() chamado\n";
    this->_context->~Context();

}

int Thread::id() {
    db<Thread>(INF) << "Thread::switch_id() chamado\n";
    return this->_id;
}

__END_API
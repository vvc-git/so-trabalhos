#ifndef thread_h
#define thread_h

#include "cpu.h"
#include "traits.h"
#include "debug.h"

__BEGIN_API

class Thread
{
protected:
    typedef CPU::Context Context;

public:
    /*
     * Cria uma Thread passando um ponteiro para a função a ser executada
     * e os parâmetros passados para a função, que podem variar.
     * Cria o contexto da Thread.
     */ 
    template<typename ... Tn>
    Thread(void (* entry)(Tn ...), Tn ... an);

    /*
     * Retorna a Thread que está em execução.
     */ 
    static Thread * running() { return _running; }

    /*
     * Método para trocar o contexto entre duas thread, a anterior (prev)
     * e a próxima (next).
     * Deve encapsular a chamada para a troca de contexto realizada pela class CPU.
     * Valor de retorno é negativo se houve erro, ou zero.
     */ 
    static int switch_context(Thread * prev, Thread * next);

    /*
     * Termina a thread.
     * exit_code é o código de término devolvido pela tarefa (ignorar agora, vai ser usado mais tarde).
     * Quando a thread encerra, o controle deve retornar à main. 
     */  
    void thread_exit (int exit_code);

    /*
     * Retorna o ID da thread.
     */ 
    int id();

    /*
    * Retorna o contexto da Tread
    */
    Context * context() {return _context;}


private:
    int _id;
    Context * volatile _context;
    static Thread * _running;


    /*
     * Contador utilizado para fornecer o identificador de cada thread. 
     */
    static int _contador_threads;

};

template<typename ... Tn>
Thread::Thread(void (* entry)(Tn ...), Tn ... an) {

    // 1. Geração de um identificador para a Thread
    _id = _contador_threads++;

    // 2. Criação do contexto da Thread
    _context = new Context(entry, an ...);

}

__END_API

#endif

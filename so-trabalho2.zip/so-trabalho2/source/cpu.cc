#include "cpu.h"
#include <iostream>

__BEGIN_API

void CPU::Context::save()
{
    // salva o contexto atual
    getcontext(&_context);
}

void CPU::Context::load()
{
    // carrega o contexto
    setcontext(&_context);
}

CPU::Context::~Context()
{
    // caso tenha uma pilha, a desaloca
    if (_stack)
        delete [] _stack;
}

int CPU::switch_context(Context *from, Context *to)
{
    // faz a troca de contexto
    return swapcontext(&from->_context, &to->_context);
}

__END_API
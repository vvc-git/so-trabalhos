#include "system.h"
#include "thread.h"


__BEGIN_API

void System::init() {
    // Desattiva o buffer padrão do stdout
    db<System>(TRC) << "System::init() chamado\n";
    setvbuf (stdout, 0, _IONBF, 0);
}


__END_API
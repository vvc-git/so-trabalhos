#ifndef cpu_h
#define cpu_h

#include <ucontext.h>
#include <iostream>
#include "traits.h"

__BEGIN_API

class CPU
{
    public:

        class Context
        {
        private:
            static const unsigned int STACK_SIZE = Traits<CPU>::STACK_SIZE;
        public:
            Context() { _stack = 0; }

            template<typename ... Tn>
            Context(void (* func)(Tn ...), Tn ... an);

            ~Context();

            void save();
            void load();

        private:            
            char *_stack;
        public:
            ucontext_t _context;
        };

    public:

        static int switch_context(Context *from, Context *to);

};

template<typename ... Tn>
CPU::Context::Context(void (* func)(Tn ...), Tn ... an) {
    getcontext(&_context); // cria um novo contexto
    _context.uc_link = NULL; // indica que nao quero que nada aconteca apos a conclusao do contexto atual

    _stack = new char [STACK_SIZE]; // cria a pilha com tamanho definido em STACK_SIZE

    if (_stack) { // se criou a pilha, altera os seguintes valores
        _context.uc_stack.ss_sp = _stack; // pilha do contexto
        _context.uc_stack.ss_flags = 0; // sinalizadores da pilha
        _context.uc_stack.ss_size =  STACK_SIZE; // tamanho da pilha
    }

    // define novamente um contexto atual para _context e a funcao a ser executada por esse contexto e' func
    makecontext(&_context, (void(*)()) func, (int) sizeof... (an), an ...);
}

__END_API

#endif
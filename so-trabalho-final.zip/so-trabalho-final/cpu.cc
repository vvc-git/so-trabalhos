#include "cpu.h"
#include <iostream>

__BEGIN_API

void CPU::Context::save()
{
    // salva o contexto atual
    getcontext(&_context);
}

void CPU::Context::load()
{
    // carrega o contexto
    setcontext(&_context);
}

CPU::Context::~Context()
{
    // caso tenha uma pilha, a desaloca
    if (_stack)
        delete [] _stack;
}

int CPU::switch_context(Context *from, Context *to)
{
    // faz a troca de contexto
    return swapcontext(&from->_context, &to->_context);
}

// Atomic operations
int CPU::finc(volatile int & number) {
    int val = 1;
    int r;

    /*
    Operação atômica de troca e adição (xadd) entre o valor da variável val e o conteúdo da variável number. 
    O resultado da operação é armazenado em number, e o valor original de number é armazenado em r.
    */
    asm("lock xadd %1, %0": "+m"(number), "=r"(r): "1"(val): "memory");
    return number;
}
int CPU::fdec(volatile int & number){
    int val = -1;
    int r;
    asm("lock xadd %1, %0": "+m"(number), "=r"(r): "1"(val): "memory");
    return number;

}

__END_API
#ifndef keyboard_h
#define keyboard_h

#include <iostream>
#include <SFML/Graphics.hpp>

class Keyboard
{
    public:
        static void processKeys();
    public:
        sf::Event envt;
};

#endif
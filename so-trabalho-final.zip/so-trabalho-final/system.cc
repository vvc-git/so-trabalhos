#include "system.h"
#include "thread.h"


__BEGIN_API


void System::init(void (*main)(void *)) {
    // Desativa o buffer padrão do stdout
    db<System>(TRC) << "System::init() chamado\n";
    setvbuf (stdout, 0, _IONBF, 0);

    // Inicializa a Thread main e dispatcher
    Thread::init(main);
}


__END_API
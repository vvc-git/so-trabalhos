#ifndef window_h
#define window_h

#include <iostream>
#include <png.h>
#include <SFML/Graphics.hpp>
#include "keyboard.h"
#include "traits.h"

__USING_API

class Window
{
public:
    Window();

    void run();

    void draw_texture(unsigned int texture, int length, int height, float angle);

    void set_key(sf::Keyboard::Key mov) {movement = mov;}

    static void update();

private:
    void load_and_bind_textures();


private:

    static sf::RenderWindow _win;
    // Maze Texture
    sf::Texture maze_tex;
    sf::Sprite maze_sprite;
    
    //Shot texture
    sf::Texture shot_tex;
    sf::Sprite shot_sprite;
    
    //Space ship texture
    sf::Texture space_ship_tex;
    sf::Sprite space_ship_sprite;

    //Enemy space ship texture
    sf::Texture enemy_ship_tex;
    sf::Sprite enemy_ship_sprite;

public:
    //Movement
    sf::Keyboard::Key movement;
};

#endif

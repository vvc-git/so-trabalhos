#include "keyboard.h"

void Keyboard::processKeys() {
        std::cout << "  foi   ";
        sf::Event event;
        if (event.type == sf::Event::KeyPressed) {
        if (event.key.code == sf::Keyboard::Escape)     {
                        std::cout << "the escape key was pressed" << std::endl;
                }
        }
        
}
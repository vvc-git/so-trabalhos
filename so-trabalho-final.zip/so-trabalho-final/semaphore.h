#ifndef semaphore_h
#define semaphore_h

#include "cpu.h"
#include "thread.h"
#include "traits.h"
#include "debug.h"
#include "list.h"

__BEGIN_API

class Semaphore
{
public:

    

    Semaphore(int v = 1) {_value = v;};
    ~Semaphore();

    void p();
    void v();


private:

    typedef Ordered_List<Thread> Waiting_Queue;

    // Atomic operations
    int finc(volatile int & number);
    int fdec(volatile int & number);

    // Thread operations
    void sleep();
    void wakeup();
    void wakeup_all();
    

private:
    //DECLARAÇÃO DOS ATRIBUTOS DO SEMÁFORO
    int _value;

    Waiting_Queue _waiting;
};

__END_API

#endif


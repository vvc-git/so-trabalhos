#include "thread.h"

__BEGIN_API
// inicializando contador de threads como 0
int Thread::_contador_threads = 0;

// inicializando _running como ponteiro nulo
Thread *Thread::_running = nullptr;

// inicializando lista de prontos
Thread::Ready_Queue Thread::_ready;

// inicializando thread main
Thread Thread::_main;

// inicializando contexto para main
CPU::Context Thread::_main_context;

// inicializando thread dispachante
Thread Thread::_dispatcher;

// inicializando fila de threads suspensas
Thread::Suspended_Queue Thread::_suspended;

Thread::~Thread() {
    db<Thread>(TRC) << "Thread::~Thread() chamado\n";
    Thread::_ready.remove(this);
    if (this->_context) {
        delete this->_context;
    }
}

int Thread::switch_context(Thread * prev, Thread * next) {
    db<Thread>(TRC) << "Thread::switch_context() chamado\n";
    
    if (prev->id() != next->id()) {
        Thread::_running = next;
        return CPU::switch_context(prev->_context, next->_context);
    }
    return 0;
}

void Thread::thread_exit(int exit_code) {
    // Desaloca a memória associada ao contexto
    db<Thread>(TRC) << "Thread::thread_exit() chamado\n";

    // altera o próprio estado para finishing
    this->_state = FINISHING;

    // inicializa o exit_code 
    this->_exit_code = exit_code;

    // Verifica se ha' alguma thread suspensa esperando
    if (this->_suspended_thread != nullptr)
        this->_suspended_thread->resume();

    // Retorna para main
    Thread::switch_context(this, &_main);
}

int Thread::id() {
    db<Thread>(TRC) << "Thread::id() chamado\n";
    return this->_id;
}

void Thread::init(void (*main)(void *)) {
    db<Thread>(TRC) << "Thread::init() chamado\n";

    /* Uso da sintaxe do placement new, que não aloca nova memória, mas sim constrói um objeto em uma área de memória já existente.
    Nesse caso, o objeto da classe Thread() é construído na área de memória apontada pela variável _ready, _main, _main_context e _dispatcher. */
    
    // Cria a Thread Main
    new (&_main) Thread((void (*) (const char[5]))main, "main");

    // Cria contexto da main
    new (&Thread::_main_context) CPU::Context();

    // Cria a Thread dispatcher
    new (&Thread::_dispatcher) Thread(&Thread::dispatcher);

    // Define estado da Thread main como executando e _running recebe endereço da Thread Main
    Thread::_main._state = RUNNING;
    Thread::_running = &Thread::_main;

    // Troca o contexto para a thread Main
    CPU::switch_context(&Thread::_main_context, Thread::_main._context);
}


void Thread::dispatcher() {
    // imprima informação usando o debug em nível TRC
    db<Thread>(TRC) << "Thread::dispacher() chamado\n";

    // enquanto existir thread do usuário:
    while (!Thread::_ready.empty()) {
        // escolha uma próxima thread a ser executada
        Thread* next = Thread::_ready.remove()->object();
        
        // atualiza o status da própria thread dispatacher para READY e reinsira a mesma em _ready
        Thread::_dispatcher._state = READY;
        Thread::_ready.insert(&Thread::_dispatcher._link);
        
        // atualiza o ponteiro _running para apontar para a próxima thread a ser executada
        Thread::_running = next;
        
        // atualiza o estado da próxima thread a ser executada
        next->_state = RUNNING;
        
        // troca o contexto entre as duas threads
        Thread::switch_context(&Thread::_dispatcher, next);
        
        // testa se o estado da próxima thread é FINISHNING e caso afirmativo a remova de _ready
        if (next->_state == FINISHING) {
            Thread::_ready.remove(next);
        }
    }
    
    // muda o estado da thread dispatcher para FINISHING
    Thread::_dispatcher._state = FINISHING;
}

void Thread::yield() {
    // imprima informação usando o debug em nível TRC
    db<Thread>(TRC) << "Thread::yield(): chamado\n";

    /* escolha uma próxima thread a ser executada
    A thread a ser removida será a dispatcher, já a removendo também da fila de prontos.
    Como a thread dispatcher nunca tem sua prioridade alterada, ela vai ser sempre a primeira da fila de prontos,
    pois foi a primeira thread a ser criada (logo depois da main) */
    Thread* next = Thread::_ready.remove()->object();
    
    // salvo qual thread esta executando (_running) em prev
    Thread* prev = Thread::_running;


    /* atualiza a prioridade da tarefa que estava sendo executada (aquela que chamou yield) com o
    timestamp atual, a fim de reinseri-la na fila de prontos atualizada (cuide de casos especiais, como
    estado ser FINISHING, SUSPENDED ou Thread main que não devem ter suas prioridades alteradas) */
    if (prev->_state != FINISHING && prev->_state != SUSPENDED && prev->_state != WAITING && Thread::_running != &Thread::_main) {
        prev->_link.rank(std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count());
        
        // reinsira a thread que estava executando na fila de prontos
        Thread::_ready.insert(&prev->_link);

        // atualiza o estado da thread que estava sendo executada
        prev->_state = READY;        
    }

    // atualiza o estado da main que estava sendo executada
    // (Precisa de if porque a main não entra no condicional acima)
    if (prev->_id == 0) prev->_state = READY;
    
    // atualiza o ponteiro _running
    Thread::_running = next;

    // atualiza o estado da próxima thread a ser executada
    next->_state = RUNNING;

    // troque o contexto entre as threads
    Thread::switch_context(prev, next);
}

int Thread::join() {

    // Thread que está execução
    Thread* t1 = Thread::_running;

    // Thread alvo (Thread que precisa terminar para que t1 volte a executar)
    Thread* t2 = this;

    // Se a thread alvo estiver em estado FINISHING
    if (t2->_state == FINISHING) {
        return t2->_exit_code; 
    }

    // Armazena a thread que vai ficar em espera
    t2->_suspended_thread = t1;

    //1. Adiciona a thread na fila de threads suspensas
    //2. Suspende a thread em execução (a adiciona na lista de threads suspensas de t2)
    t1->suspend();

    return this->_exit_code;

}

void Thread::suspend() {
    
    if (this->_state == READY) _ready.remove(this);

    // 1. Bloqueia a thread que estava em execução
    this->_state = SUSPENDED;

    // Adiciona a thread alvo na fila de suspensas da running
    Thread::_suspended.insert(&this->_suspended_link);

    // Verifica se a thread em execução é a thread que vai ser suspensa. Se sim, deve liberar o processador
    if (Thread::_running == this) yield();

}

void Thread::resume() {
    
    db<Thread>(TRC) << "Thread::resume(): chamado\n";

    // Altera o estado da thread que esta suspensa e reinsere na fila
    if (this->_state == SUSPENDED) {

        Thread::_suspended.remove(this);
        
        this->_state = READY;
        
        Thread::_ready.insert(&this->_link);
    }
    
}

// Thread operations
void Thread::sleep() {
    db<Thread>(TRC) << "Thread::sleep(): chamado\n";

    // Thread que vai ficar em espera
    Thread * waiting = this;

    // 1. Muda o estado da thread em execução 
    waiting->_state = WAITING;

    // 2. Libera o processaor;
    Thread::yield();


}
void Thread::wakeup() {
    db<Thread>(TRC) << "Thread::wakeup(): chamado\n";

    Thread * awake = this;

    if (awake->_state == WAITING) {

        awake->_state = READY;

        // Reinsere a thread t2 na fila de prontos
        Thread::_ready.insert(&awake->_link);

        // Para garantir que outras threads tenham um tempo de uso do processador (justiça)
        Thread::yield();
    }


}
__END_API

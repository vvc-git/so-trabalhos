#include "semaphore.h"

__BEGIN_API

Semaphore::~Semaphore() {
    db<Semaphore>(TRC) << "Semaphore::~Semaphore() chamado\n";
    if (_waiting.size() > 0) {
        wakeup_all();
    }
}

void Semaphore::p() {
    db<Semaphore>(TRC) << "Semaphore::p(): chamado\n";
    if (_value > 0) {
        fdec(_value);
    } else {
        sleep();
    }
}
void Semaphore::v() {
    db<Semaphore>(TRC) << "Semaphore::v(): chamado\n";
    if (_waiting.empty()) {
        finc(_value);
    } else {
        wakeup();
    }
}

// Atomic operations
int Semaphore::finc(volatile int & number) {
    db<Semaphore>(TRC) << "Semaphore::finc(): chamado\n";
    return CPU::finc(_value);
}
int Semaphore::fdec(volatile int & number) {
    db<Semaphore>(TRC) << "Semaphore::fdec(): chamado\n";
    return CPU::fdec(_value);    
}

// Thread operations
void Semaphore::sleep() {
    db<Semaphore>(TRC) << "Semaphore::sleep(): colocou a thread " << Thread::running()->id() << " para dormin\n";
    
    
    // Pega a thread em execução
    Thread * t1 = Thread::running();
    
    // Adiciona o tempo atual como condição para prioridade na fila de espera
    int now =std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count();
    t1->set_waiting_link(now);
    
    // Insere a thread em execução na fila de espera
    _waiting.insert(t1->get_waiting_link());
    
    // Atualiza os estados e libera o processador
    t1->sleep();

}
void Semaphore::wakeup() {
    // Retira uma thread da fila de threads em espera
    Thread * t2 = _waiting.remove()->object();
    
    db<Semaphore>(TRC) << "removido na fila " << t2 <<"\n";
    
    // Atualiza os estados e libera o processador 
    t2->wakeup();

}
void Semaphore::wakeup_all() {
    db<Semaphore>(TRC) << "Semaphore::wakeup_all(): chamado\n";
    while (_waiting.size() > 0)
        wakeup();

}

__END_API
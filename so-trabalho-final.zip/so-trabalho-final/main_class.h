#ifndef main_class_h
#define main_class_h

#include <iostream>
#include "window.h"
#include "thread.h"

__BEGIN_API

class Main
{
public:
    Main() {
    }

    ~Main() {}

    static void run(void * name)
    {   
        std::cout <<"inicio 1\n";
        _threads_list[0] = new Thread(windowRun);
        _threads_list[1] = new Thread(_key->processKeys);

        std::cout <<"inicio 2\n";
        _threads_list[0]->join();
        _threads_list[1]->join();
        std::cout <<"fim\n";

        delete _threads_list[0];
        delete _threads_list[1];
    }

    static void windowRun() {
        _window = new Window();
        _window->run();
        delete _window;
        Main::_threads_list[0]->thread_exit(0);
    }
        
    private:
        static Thread *_threads_list[2];
        static Window *_window;
        static Keyboard *_key;
        
};

__END_API

#endif


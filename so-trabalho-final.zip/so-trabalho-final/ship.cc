#include "ship.h"

void Ship::set_movement(sf::Keyboard::Key key) {
    this->_key = key;
}

#include "main_class.h"

__BEGIN_API

Thread *Main::_threads_list[2];
Window *Main::_window;
Keyboard *Main::_key;
__END_API
#ifndef thread_h
#define thread_h

#include "cpu.h"
#include "traits.h"
#include "debug.h"
#include "list.h"
#include <ctime> 
#include <chrono>
#include "semaphore.h"

__BEGIN_API

class Thread
{
protected:
    typedef CPU::Context Context;
public:

    typedef Ordered_List<Thread> Ready_Queue;
    typedef Ordered_List<Thread> Suspended_Queue;
    typedef Ordered_List<Thread> Waiting_Queue;


    // Thread State
    enum State {
        RUNNING,
        READY,
        FINISHING,
        SUSPENDED,
        WAITING
    };

    /*
     * Construtor vazio. Necessário para inicialização, mas sem importância para a execução das Threads.
     */ 
    Thread() { }

    /*
     * Cria uma Thread passando um ponteiro para a função a ser executada
     * e os parâmetros passados para a função, que podem variar.
     * Cria o contexto da Thread.
     * PS: devido ao template, este método deve ser implementado neste mesmo arquivo .h
     */ 
    template<typename ... Tn>
    Thread(void (* entry)(Tn ...), Tn ... an);

    /*
     * Destrutor de uma thread. Realiza todo os procedimentos para manter a consistência da classe.
     */ 
    ~Thread();

    /*
     * Retorna a Thread que está em execução.
     */ 
    static Thread * running() { return _running; };

    /*
     * Método para trocar o contexto entre duas thread, a anterior (prev)
     * e a próxima (next).
     * Deve encapsular a chamada para a troca de contexto realizada pela class CPU.
     * Valor de retorno é negativo se houve erro, ou zero.
     */ 
    static int switch_context(Thread * prev, Thread * next);

    /*
     * Termina a thread.
     * exit_code é o código de término devolvido pela tarefa
     * Quando a thread encerra, o controle deve retornar à main. 
     */  
    void thread_exit (int exit_code);

    /*
     * Retorna o ID da thread.
     */ 
    int id();

    /*
     * Realiza a inicialização da class Thread.
     * Cria as Threads main e dispatcher.
     */ 
    static void init(void (*main)(void *));

    /*
     * Daspachante (disptacher) de threads. 
     * Executa enquanto houverem threads do usuário.
     * Chama o escalonador para definir a próxima tarefa a ser executada.
     */
    static void dispatcher(); 


    /*
     * Devolve o processador para a thread dispatcher que irá escolher outra thread pronta
     * para ser executada.
     */
    static void yield(); 


    /*
    * Este método deve suspender a thread em execução até que a thread “alvo” finalize. O inteiro 
    * é o exit_code da thread alvo
    */
    int join();

    /*
    * Suspende a Thread até que resume() seja chamado
    */
    void suspend();

    /*
    * Coloca uma Thread que estava suspensa de volta para a fila de prontos
    */
    void resume();

    // Operações da thread para o semáforo;
    void sleep();
    void wakeup();

    // Getter e Setter para alterar o rank de prioridade para a fila de threads em espera
    void set_waiting_link(int v) {_waiting_link.rank(v);};
    Waiting_Queue::Element* get_waiting_link() {return  &this->_waiting_link;};

private:
    int _id;
    Context * volatile _context;
    static Thread * _running;
    
    static Thread _main; 
    static CPU::Context _main_context;
    static Thread _dispatcher;
    static Ready_Queue _ready;
    Ready_Queue::Element _link;
    volatile State _state;

    /*
     * Contador utilizado para fornecer o identificador de cada thread. 
     */
    static int _contador_threads;

     /*
     * Fila para armazenar as threads que estão supensas 
     */
    static Suspended_Queue _suspended;

    /*
     * Atributo para armazenar o código do argumento da função Thread_exit
     */
    int _exit_code;

    /*
    * Atributo para armazenar a thread que está em espera o fim da execução
    */
    Thread * _suspended_thread;

    /*
     * Elemento para armazenar as threads que estão supensas 
     */
    Suspended_Queue::Element _suspended_link;

    /*
     * Elemento para armazenar as threads que estão em espera
    */
    Waiting_Queue::Element _waiting_link;


};

template<typename ... Tn>
inline Thread::Thread(void (* entry)(Tn ...), Tn ... an): _link(this, (std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::high_resolution_clock::now().time_since_epoch()).count()))  /* inicialização de _link */
{
    // 1. Geração de um identificador para a Thread
    _id = _contador_threads++;

    // 2. Criação do contexto da Thread
    _context = new Context(entry, an ...);

    // Inicializa o elemento que representa a thread na fila de suspensas
    _suspended_link = Suspended_Queue::Element(this, 0);

    // Inicializa o elemento que representa a thread na fila de espera
    _waiting_link = Waiting_Queue::Element(this, 0);

    // Inicializa a thread que foi suspensa
    _suspended_thread = nullptr;

    // 3. Inicializa o estado da thread
    _state = READY;

    // 4. Insere a thread na fila de prontos, exceto a Thread main
    if (_id > 0)
        _ready.insert(&_link);
}

__END_API

#endif

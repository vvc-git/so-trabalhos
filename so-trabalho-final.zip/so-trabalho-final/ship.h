#include <SFML/Graphics.hpp>

class Ship
{
public:
    Ship();
    ~Ship();
    void set_movement(sf::Keyboard::Key key);

private:
    sf::Keyboard::Key _key;

};
